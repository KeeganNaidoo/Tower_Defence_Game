using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Defender : MonoBehaviour
{
    public GameObject projectilePrefab;
    public Transform projectileSpawnPoint;
    public float attackRange = 10f;
    public float attackCooldown = 2f;
    public float projectileSpeed = 20f;
    public float rotationSpeed = 5f;
    public float hp = 50f;  // Health of the defender

    private float attackCooldownTimer;
    private Transform currentTarget;

    void Update()
    {
        FindTarget();

        if (currentTarget != null)
        {
            RotateTowards(currentTarget);

            if (attackCooldownTimer <= 0f)
            {
                Attack();
                attackCooldownTimer = attackCooldown;
            }

            attackCooldownTimer -= Time.deltaTime;
        }
    }

    // Virtual method to be overridden by specific defender types
    protected virtual void Attack()
    {
        ShootProjectile(currentTarget);
    }

    void ShootProjectile(Transform target)
    {
        GameObject projectile = Instantiate(projectilePrefab, projectileSpawnPoint.position, Quaternion.identity);
        Projectile proj = projectile.GetComponent<Projectile>();
        if (proj != null)
        {
            proj.Initialize(target, projectileSpeed);
        }
    }

    void RotateTowards(Transform target)
    {
        Vector3 direction = (target.position - transform.position).normalized;
        Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
        transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * rotationSpeed);
    }

    public void TakeDamage(float damage)
    {
        hp -= damage;
        if (hp <= 0)
        {
            Destroy(gameObject);
        }
    }

    void FindTarget()
    {
        Collider[] enemiesInRange = Physics.OverlapSphere(transform.position, attackRange);
        foreach (Collider enemyCollider in enemiesInRange)
        {
            Enemy enemy = enemyCollider.GetComponent<Enemy>();
            if (enemy != null)
            {
                currentTarget = enemy.transform;
                break;
            }
        }
    }
}
